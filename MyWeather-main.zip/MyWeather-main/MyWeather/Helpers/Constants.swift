//
//  Constants.swift
//  MyWeather
//
//  Created by Дмитрий Садырев on 19.05.2022.
//

import Foundation
import SwiftUI

public let APIKey = "918575e9973a538206f99ee7305be0e9"

public let locationByCoordinatesURL = "https://api.openweathermap.org/geo/1.0/reverse"
public let locationByCityURL = "https://api.openweathermap.org/geo/1.0/direct"
public let weatherURL = "https://api.openweathermap.org/data/2.5/onecall"


